# gen\_main\_xml.bat
用于从 main\_orig.xml 生成 main.xml
没有输出错误就代表成功生成了

