#include <stdio.h>
#include <fstream>
#include <sstream>
#include <Windows.h>

#include "debug.h"


std::fstream __debug_file;
