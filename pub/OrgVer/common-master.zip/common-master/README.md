Common Copyright (C) 2012-2048 twofei

软件说明
========
Win32平台上的串口通信调试助手

软件主页
========
http://blog.twofei.com/566/

编译环境
========
为了方便管理, 目前只有VS2013的项目文件.
开发语言为C++/C++11.

联系作者
========
QQ:191035066
Em:anhbk@qq.com

