#pragma once

void show_pinctrl(HWND owner, std::function<HANDLE()> get_com_handle);
