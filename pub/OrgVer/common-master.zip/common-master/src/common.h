#ifndef __COMMON_H__
#define __COMMON_H__

#endif//!__COMMON_H__
